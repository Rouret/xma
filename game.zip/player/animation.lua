local Animation = {}

function Animation.update(dt)
end

return Animation
