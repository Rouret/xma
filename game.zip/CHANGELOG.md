# Changelog

## v0.0.5 - 31/01/25

### Added or Changed
- Correctioen du bug quand on arrive en bas de la map
- 1 monstres par biomes

## v0.0.4 - 31/01/25

### Added or Changed
- 3 biomes

## v0.0.3 - 24/01/25
### Added or Changed
- Add Fire Staff
- Add biome

## v0.0.2 - 12/01/25

### Added or Changed
- Add UI
- Add XP
- Add choice


## v0.0.1 - 12/01/25

### Added or Changed
- Added gun weapon
- Added stationnary_enemy
- Added basic UI
