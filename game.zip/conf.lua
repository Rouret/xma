function love.conf(t)
    t.title = "Xma"
    t.author = "Rouret Lucas"

    t.window.title = "Xma"
    t.window.icon = "sprites/icon.png"
    t.window.fullscreen = false

    t.window.width = 1920
    t.window.height = 1080
end
